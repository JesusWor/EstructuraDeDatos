// Equipo 5
// Angel Gabriel Camacho Perez - A01743075
// Ana Paula Navarro Hernandez - A01644875
// Jesus Eduardo Escobar Meza - A01743270
// Descripcion: Este programa maneja una lista enlazada de registros y lee un archivo que contienen registros los cuales se ordenan de menor a mayor usando la IP de los regstros y genera un nuevo archivo con los regisrtros ordenados
// ademas de que permite hacer la busqueda de los registros que se quieren ingresar pidiendo al usuario un rango que tiene un inicio y un fin dichos registros son almacenados en un nuevo archivo .txt
// Fecha: 12 de octubre del 2024

#include "Bitacora.h"
#include <iostream>
#include <fstream> //para manipular los archivos 
#include <stdexcept> //para manejar excepciones

using namespace std;

int main(){

    //Carga la bitacora a partir de un archivo.
    Bitacora* archivo= new Bitacora("bitacora.txt");

    //Ordena la Bitacora
    archivo->ordenarBitacora();

    //Exporta la bitacora completa
    archivo->exportarBitacoraCompleta("bitacoraOrdenadaIP-Eq5.txt");

    int N=1;


    // Borrar las bitacoras dinamicas
    delete archivo;
    cout<<"Eliminacion de Bitacora exitosa.";
    
    return 0; 
}