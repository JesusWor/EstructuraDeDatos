//Equipo 5
//Ãngel Gabriel Camacho PÃ©rez - A01743075
//Ana Paula Navarro HernÃ¡ndez - A01644875
//JesÃºs Eduardo Escobar Meza - A01743270
//DescripciÃ³n: Este programa lee un archivo de texto y lo ordena mediante el mÃ©todo de ordenamiento Merge
//Fecha: 18 de septiembre del 2024

#ifndef REGISTRO_H
#define REGISTRO_H

#include <iostream>
#include <vector>
#include <iomanip> 
using namespace std;

class Registro{
private:
    //Atributos que almacenan la informaciÃ³n de un registro
    string mes;
    string mesN;
    string dia;
    string tiempo;
    string direccionIP;
    string razon;
    long int ID;
    int completeIP;

    int ConstruirIP(); //MÃ©todo para generar una IP
    
public:
    Registro *next;

    Registro();
    Registro(string linea, Registro* next);
    Registro(string mes, string dia, string tiempo, string direccionIP, string razon, Registro* next);

    //MÃ©todos de acceso (getters)
    string GetMes();
    string GetDia();
    string GetTiempo();
    string GetDireccionIP();
    string GetRazon();
    int GetID(); 
};

#endif