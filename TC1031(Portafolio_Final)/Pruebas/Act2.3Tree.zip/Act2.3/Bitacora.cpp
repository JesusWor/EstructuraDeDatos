//Equipo 5
//Ángel Gabriel Camacho Pérez - A01743075
//Ana Paula Navarro Hernández - A01644875
//Jesús Eduardo Escobar Meza - A01743270
//Descripción: Este programa lee un archivo de texto y lo ordena mediante el método de ordenamiento Merge
//Fecha: 18 de septiembre del 2024
//Referencias: Para ExportarBitacora utilizamos de referencia el siguiente video de youtube: https://www.youtube.com/watch?v=LTSF2wnfNH0&list=PLCTD_CpMeEKTofxs7iottRxJ5YPM7BOcc&index=139
//Novato, P. [@programadornovato]. (s/f). 133.- C++ desde cero 2019🦸‍♂️ [Crear Archivos en c++]. Youtube. Recuperado el 18 de septiembre de 2024, de https://www.youtube.com/watch?v=LTSF2wnfNH0&list=PLCTD_CpMeEKTofxs7iottRxJ5YPM7BOcc&index=139

#include "Bitacora.h"
#include "Registro.h"

// <iostream> <vector> <iomanip> Ya están en el .h
#include <fstream>
#include <string>

Bitacora::Bitacora(){
    this->size=0;
    this->head=nullptr;
    this->left=nullptr;
    this->right=nullptr;
}

Bitacora::~Bitacora(){
    while(!IsEmpty()){
        RemoveLast();
    }
}

void Bitacora::LeerArchivo(string arc){
    ifstream archivo(arc);
    if(! archivo.is_open()){
        cout << "Error al abrir el archivo" <<"\n";
        exit(EXIT_FAILURE);
    }

    string linea;
    while (getline(archivo, linea)) {
        InsertFirst(linea);
    }
    archivo.close();
}

int Bitacora::GetSize(){
    //Retorna la cantidad de registros en la bitácora
    return size;
}

//mergeSort
Registro* Bitacora::OrdenarBitacora(Registro* head){
    //Se inicia el proceso de ordenamiento usando Merge Sort
    if(head == nullptr || head->next == nullptr){
        return head;
    }
    Registro* medio = OrdenaMerge(head);
    Registro* nextMedio = medio->next;
    medio->next = nullptr;

    Registro* left = OrdenarBitacora(head);
    Registro* right = OrdenarBitacora(nextMedio);
    return Mezcla(left, right);
}

//getMiddle
Registro* Bitacora::OrdenaMerge(Registro* head){
    //Para ordenar los registros 
    if(head == nullptr){
        return head;
    }
    Registro* slow = head;
    Registro* fast = head->next;
    while(fast != nullptr && fast->next != nullptr){
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}

//sortedMerge
Registro* Bitacora::Mezcla(Registro* left, Registro* right){   
    //Mezcla dos mitades ordenadas 
    if(left == nullptr){
        return right;
    }
    if(right == nullptr){
        return left;
    }
    Registro* mezcla = nullptr;
    if(left->GetID() <= right->GetID()){
        mezcla = left;
        mezcla->next = Mezcla(left->next, right);
    } else {
        mezcla = right;
        mezcla->next = Mezcla(left, right->next);
    }
    return mezcla;
}

Registro* Bitacora::BusquedaBinaria(Registro* head){
    //Implementamos búsqueda binaria para encontrar un registro por ID
    int min=0, max=Registro.size()-1, avg;
    while(min <= max){             
        avg= (min+max)/2;
        if(Registro[avg].GetID()==iniID){    
            return avg;
        } else if(iniID>registros[avg].GetID()){
            min=avg+1;
        } else {
            max=avg-1;
        }
    }
    return min;
}

void Bitacora::ExportarBitacora(int N, int j){
    //Exporta los registros a un archivo de texto
    string nombre = "salida"+to_string(N)+"-eq5.txt";
    fstream file;
    file.open(nombre,ios::out);
    if(file.is_open()){
        Registro* current = head;
        while(current != nullptr) {
            file<<current->GetMes() <<" " <<current->GetDia() <<" " <<current->GetTiempo() <<" " <<current->GetDireccionIP() <<" " <<current->GetRazon() <<"\n";
            current = current->next;
        }
        file.close();
        cout<<"Archivos guardados exitosamente" <<"\n \n";
    } else {
        cout<<"Error al abrir el archivo" <<"\n";   
    }
}

void Bitacora::PrintRegistro(){
    //Crea un archivo de texto con los registros ordenados
    fstream file;
    file.open("BitacoraOrdenada.txt",ios::out);
    if(file.is_open()){
        Registro* current = head;
        while(current != nullptr) {
            file<<current->GetMes() <<" " <<current->GetDia() <<" " <<current->GetTiempo() <<" " <<current->GetDireccionIP() <<" " <<current->GetRazon() <<"\n";
            current = current->next;
        }
        file.close();
        cout<<"Archivos guardados exitosamente" <<"\n";
    } else {
        cout<<"Error al abrir el archivo" <<"\n";       
    }
}


//Devuelve true si la lista está vacía
bool Bitacora::IsEmpty(){
    return this->head==nullptr;
}