//Equipo 5
//Ãngel Gabriel Camacho PÃ©rez - A01743075
//Ana Paula Navarro HernÃ¡ndez - A01644875
//JesÃºs Eduardo Escobar Meza - A01743270
//DescripciÃ³n: Este programa lee un archivo de texto y lo ordena mediante el mÃ©todo de ordenamiento Merge
//Fecha: 18 de septiembre del 2024

#include "Registro.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include <sstream>
#include <ctime> //Funciones para trabajar con fechas y horas.

using namespace std;

Registro::Registro() : Registro("","","","","", nullptr){
}

Registro::Registro(string linea, Registro* next) {
    InsertLine(linea);
    this->next= next;
}

Registro::Registro(string mes, string dia, string tiempo, string direccionIP, string razon, Registro* next){
    //Crear un registro con cada parte por separado
    this->mes= mes;
    this->dia= dia;
    this->tiempo= tiempo;
    this->direccionIP= direccionIP;
    this->razon= razon;
    this->IP_ID= ConstruirID();
    this->next= next;
}

//construimos la IP
int Registro::ConstruirIP(){
    //Separamos la IP y el puerto 
    string IP, puerto;
    int pos, pos1, pos2, pos3;
    string part1, part2, part3, part4;
    pos=direccionIP.find(':');

    //Obtenemos la Ip y el puerto
    IP=direccionIP.substr(0, pos);
    puerto=direccionIP.substr(pos+1);

    //Separamos la IP en 4 partes
    pos1=IP.find('.');
    part1=IP.substr(0, pos1);

    pos2=IP.find('.', pos1+1);
    part2 = IP.substr(pos1+1, pos2-pos1-1);

    pos3=IP.find('.', pos2+1);
    part3=IP.substr(pos2+1, pos3-pos2-1);
    
    part4=IP.substr(pos3+1);


    //ya que la separamos, verificamos que todas las partes tengan 3 dÃ­gitos, y si no, las rellenamos con 0
    //parte 1
    if(part1.length()<3){
        part1="0"+part1;
    }
    else if(part1.length()<2){
        part1="00"+part1;
    }

    //parte 2
    if(part2.length()<3){
        part2="0"+part2;
    }
    else if(part2.length()<2){
        part2="00"+part2;
    }

    //parte 3
    if(part3.length()<3){
        part3="0"+part3;
    }
    else if(part3.length()<2){
        part3="00"+part3;
    }

    //parte 4
    if(part4.length()<3){
        part4="0"+part4;
    }
    else if(part4.length()<2){
        part4="00"+part4;
    }

    //ya que nos aseguramos de que las partes tengan 3 dÃ­gitos, las unimos en una sola cadena fara volver a formar la IP completa
    string completeIP = part1+"."+part2+"."+part3+"."+part4+":"+puerto; 
    return stoi(completeIP);
}

string Registro::GetMes(){
    return mes;
}

string Registro::GetDia(){
    return dia;
}

string Registro::GetTiempo(){
    return tiempo;
}

string Registro::GetDireccionIP(){
    return direccionIP;
}

string Registro::GetRazon(){
    return razon;
}

int Registro::GetID(){
    return ID;
}