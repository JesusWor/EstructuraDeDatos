//Equipo 5
//Ángel Gabriel Camacho Pérez - A01743075
//Ana Paula Navarro Hernández - A01644875
//Jesús Eduardo Escobar Meza - A01743270
//Descripción: Este programa lee un archivo de texto y lo ordena mediante el método de ordenamiento Merge
//Fecha: 18 de septiembre del 2024

#include "Bitacora.h"
#include <iostream>
#include <fstream> //para manipular los archivos 
#include <vector> 
#include <stdexcept> //para manejar excepciones

using namespace std;

int main(){
    string resp; 
    bool repeticion= true;
    int N=1; //Contador para exportar registros
    int i;

    //Sirve para carga la bitácora a partir de un archivo.
    Bitacora* archivo= new Bitacora();
    archivo->LeerArchivo("bitacora-1.txt");
    archivo->OrdenarBitacora(); 
    archivo->PrintRegistro();

    /*
    Bitacora archivo();
    archivo.LeerArchivo("bitacora-1.txt");
    archivo.OrdenarBitacora(); 
    archivo.PrintRegistro();
    */
    
    
   // Hay que reestructurar todo el main ya que debe funcionar con apuntadores como arriba


    while(repeticion){ //ciclo para repetir el programa 
        //Activa la búsqueda de registros por fecha y manda un aviso si ocurre un error al ingresar los datos mal
        try {
            Bitacora busqueda(archivo.BuscarRegistro());
            if(busqueda.GetSize()==0){ 
                cout<<"No hay registros en ese rango de tiempo" <<"\n";
            }
            i = busqueda.GetSize(); //Obtiene la cantidad de registros encontrados
            busqueda.ExportarBitacora(N, i); //Exporta los registros encontrados a un archivo txt
            N++;
        } 
        catch (const std::length_error& e) {
            cout<< "Error ocurrido al ingresar los datos, favor de hacerlo de nuevo." <<"\n";
        } 
        while(true){
            //Pregunta al usuario si desea buscar otro rango de fechas
            cout<<"¿Quieres hacer otra busqueda (y/n)?"<<endl;
            getline(cin, resp);
            if(resp == "y"){
                cout<<"\n";
                break; //Regresa al inicio del bucle principal
            }
            else if(resp == "n"){
                cout<<"Gracias por usar el programa"<<endl;
                repeticion=false; //Termina el bucle principal
                break;
            }
            else{
                cout<<"Respuesta invalida"<<endl<<endl;
            }   
        }
    }

    // Borrar las bitacoras dinámicas
    delete archivo;
    //delete busqueda;
    
    return 0; 
}