//Equipo 5
//Ángel Gabriel Camacho Pérez - A01743075
//Ana Paula Navarro Hernández - A01644875
//Jesús Eduardo Escobar Meza - A01743270
//Descripción: Este programa lee un archivo de texto y lo ordena mediante el método de ordenamiento Merge
//Fecha: 18 de septiembre del 2024

#ifndef BITACORA_H
#define BITACORA_H

#include "Registro.h"

#include <iostream>
#include <vector>
#include <iomanip>  
using namespace std;

class  Bitacora{
private:
    int size;
        Registro *head,
            *left,
            *right;
    
    Registro* OrdenaMerge(Registro* head); //Ordena los registros utilizando Merge Sort
    Registro* Mezcla(Registro* left, Registro* right);
    Registro* BusquedaBinaria(Registro* head); //Realiza una búsqueda binaria para encontrar un registro por ID
    
public:
    Bitacora(); //Constructor por defaut
    ~Bitacora(); //Destructor

    void LeerArchivo(string archivo); //Obtiene los registros contenidos en un archivo

    int GetSize(); //Retorna la cantidad de registros en la bitácora
    void PrintRegistro(); //Imprime un registro específico en la consola
    Registro* OrdenarBitacora(Registro *head); //Ordena los registros de la bitácora
    void ExportarBitacora(int N, int j); //Exporta los registros a un archivo de texto

    bool IsEmpty();
    string First(); //Exc invalid_argument
    string Last(); //Exc invalid_argument
    string GetAt(int pos); //Exc invalid_argument
    void SetAt(int pos, string data); //Exc invalid_argument
    void InsertFirst(string reg);
    void InsertLast(string reg);
    void InsertAt(int pos, string reg); //pos:[0,size] Exc invalid_argument
    void RemoveFirst(); //Exc invalid_argument
    void RemoveLast(); //Exc invalid_argument
    void RemoveAt(int pos); //pos:[0,size] Exc invalid_argument
};

#endif